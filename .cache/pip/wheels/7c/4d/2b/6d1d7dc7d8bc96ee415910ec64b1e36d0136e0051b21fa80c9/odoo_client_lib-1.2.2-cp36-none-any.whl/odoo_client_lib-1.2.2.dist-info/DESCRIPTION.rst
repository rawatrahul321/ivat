See the home page for any information: https://github.com/odoo/odoo-client-lib .


