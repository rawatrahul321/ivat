# -*- coding: utf-8 -*-

__author__ = 'Odoo Community Association (OCA)'
__email__ = 'support@odoo-community.org'
__version__ = '2.0.0'
__doc__ = """A library with support functions to be called from Odoo \
migration scripts."""
__license__ = "AGPL-3"
